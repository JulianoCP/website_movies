<?php include("../paginas/cabe.php"); ?>
<?php  include '../conexao.php';?>
<div class="container">

<?php $sql = "SELECT F.NOME AS FILMENOME, F.ANO AS ANOFILME, F.DURACAO AS DURAFILME,
        F.IMG, F.SINOPSE,F.DIRETOR,F.ATOR, C.NOMECAT AS CATNOME, I.NOME AS IDIFILME,R.NOME AS RESUFILME, FF.NOME AS FFNOME
        FROM FILMES AS F, IDIOMA AS I,RESOLUCAO AS R,CATEGORIA AS C,FORMATO AS FF
        WHERE F.idFilmes = '{$_GET['id']}'
        AND C.idCategoria = F.Categoria_idCategoria
        AND I.idIdioma = F.Idioma_idIdioma
        AND FF.idFormato = F.Formato_idFormato
        AND R.idresolucao = F.resolucao_idresolucao";

  $result = $conn->query($sql);
  if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
      echo "<div class='row justify-content-center'>
          <figure class='figure'>
            <img src='../src/img/logo/".$row["IMG"]."' class='figure-img img-fluid rounded' alt='' height='500' width='1500>
            <figcaption class='figure-caption'></figcaption>
          </figure>
          <div class='col'>
              <h5 class='text'></h5>
          </div>
        </div>
      <div class=' form-row'>
          <div class='form-group col-md-4'>
            <label for='inputAddress'><span style='color:red;'>Nome do Filme</span></label>
            <h3 class='form-control'>".$row["FILMENOME"]."</h3>
          </div>
          <div class='form-group col-md-4'>
            <label for='inputAddress'><span style='color:red;''>Ano de Lamçamento</span></label>
            <h3 class='form-control'>".$row["ANOFILME"]."</h3>
          </div>
          <div class='form-group col-md-4'>
            <label for='inputAddress'><span style='color:red;'>Duração do Filme</span></label>
            <h3 class='form-control'>".$row["DURAFILME"]."</h3>
          </div>
          <div class='form-group col-md-4'>
            <label for='inputAddress'><span style='color:red;'>Resolucao do Filme</span></label>
            <h3 class='form-control'>".$row["RESUFILME"]."</h3>
          </div>
          <div class='form-group col-md-4'>
            <label for='inputAddress'><span style='color:red;'>Idioma do Filme</span></label>
            <h3 class='form-control'>".$row["IDIFILME"]."</h3>
          </div>
          <div class='form-group col-md-4'>
            <label for='inputState'><span style='color:red;'>Gênero do Filme</span></label>
            <h3 class='form-control'>".$row["CATNOME"]."</h3>
          </div>
          <div class='form-group col-md-4'>
            <label for='inputState'><span style='color:red;'>Diretor do Filme</span></label>
            <h3 class='form-control'>".$row["DIRETOR"]."</h3>
          </div>
          <div class='form-group col-md-4'>
            <label for='inputState'><span style='color:red;'>Ator Principal do Filme</span></label>
            <h3 class='form-control'>".$row["ATOR"]."</h3>
          </div>
          <div class='form-group col-md-4'>
            <label for='inputState'><span style='color:red;'>Formato do Filme</span></label>
            <h3 class='form-control'>".$row["FFNOME"]."</h3>
          </div>
          <div class='form-group col-md-12'>
            <label for='inputState'><span style='color:red;'>Sinopse</span></label>
            <h3 class='form-control'>".$row["SINOPSE"]."</h3>
          </div>
        </div>";
    }
  } else {
    echo "0 results";
  }
  ?>







  <div class="text-center">
    <a href="#"><button type="button" class="btn btn-outline-danger">DOWNLOAD</button></a>
  </div>
</div>
<?php include("../paginas/rodape.php") ?>
